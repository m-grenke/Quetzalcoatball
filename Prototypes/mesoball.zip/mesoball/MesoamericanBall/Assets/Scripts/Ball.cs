﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour 
{
	Rigidbody2D rb2d;
	public float force = 10f;
	public float upAdditional = 5f;
	void Start()
	{
		rb2d = GetComponent<Rigidbody2D> ();
	}

	void OnCollisionEnter2D(Collision2D col2d)
	{
		print (rb2d.velocity.magnitude);
		Vector2 dir = col2d.contacts [0].normal + (Vector2.up * upAdditional);
		rb2d.AddForce (dir.normalized * force, ForceMode2D.Impulse);
	}
}
